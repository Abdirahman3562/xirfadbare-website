
import React, { useState } from 'react';
import DataTable from '../components/DataTable';
import { MOCK_STUDENTS } from '../constants';
import { Student } from '../types';

const StudentsPage = () => {
  const [showModal, setShowModal] = useState(false);

  const columns = [
    { header: 'Roll No', accessor: 'rollNo' as keyof Student },
    { 
      header: 'Name', 
      accessor: (s: Student) => (
        <div className="flex items-center gap-3">
          <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(s.name)}`} className="w-8 h-8 rounded-full" alt="" />
          <span>{s.name}</span>
        </div>
      )
    },
    { header: 'Class', accessor: 'class' as keyof Student },
    { header: 'Section', accessor: 'section' as keyof Student },
    { header: 'Parent', accessor: 'parentName' as keyof Student },
    { 
      header: 'Attendance', 
      accessor: (s: Student) => (
        <div className="flex items-center gap-2">
          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className={`h-full ${s.attendance > 80 ? 'bg-emerald-500' : s.attendance > 50 ? 'bg-amber-500' : 'bg-red-500'}`} 
              style={{ width: `${s.attendance}%` }}
            ></div>
          </div>
          <span className="text-xs">{s.attendance}%</span>
        </div>
      )
    },
    { 
      header: 'Status', 
      accessor: (s: Student) => (
        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
          s.status === 'active' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'
        }`}>
          {s.status}
        </span>
      )
    },
    {
      header: 'Actions',
      accessor: () => (
        <div className="flex gap-2">
          <button className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"><i className="fa-solid fa-edit"></i></button>
          <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"><i className="fa-solid fa-trash"></i></button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Student Directory</h2>
          <p className="text-slate-500 text-sm">Manage all students across different branches and classes.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
        >
          <i className="fa-solid fa-plus"></i>
          Add Student
        </button>
      </div>

      <DataTable columns={columns} data={MOCK_STUDENTS} />

      {/* Simple Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-xl font-bold text-slate-800">Add New Student</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600"><i className="fa-solid fa-times text-xl"></i></button>
            </div>
            <div className="p-8 grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Full Name</label>
                <input type="text" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500" placeholder="e.g. Alice Johnson" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Roll Number</label>
                <input type="text" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500" placeholder="e.g. 101" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Class</label>
                <select className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500">
                  <option>Grade 9</option>
                  <option>Grade 10</option>
                  <option>Grade 11</option>
                  <option>Grade 12</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Section</label>
                <select className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500">
                  <option>A</option>
                  <option>B</option>
                  <option>C</option>
                </select>
              </div>
            </div>
            <div className="p-8 border-t border-slate-100 flex justify-end gap-4">
              <button onClick={() => setShowModal(false)} className="px-6 py-2 font-bold text-slate-500 hover:text-slate-700">Cancel</button>
              <button onClick={() => setShowModal(false)} className="px-8 py-2 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200">Save Student</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentsPage;
