
import React from 'react';
import { UserRole } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { MOCK_STUDENTS, MOCK_INVOICES } from '../constants';

const data = [
  { name: 'Mon', income: 4000, expenses: 2400 },
  { name: 'Tue', income: 3000, expenses: 1398 },
  { name: 'Wed', income: 2000, expenses: 9800 },
  { name: 'Thu', income: 2780, expenses: 3908 },
  { name: 'Fri', income: 1890, expenses: 4800 },
  { name: 'Sat', income: 2390, expenses: 3800 },
  { name: 'Sun', income: 3490, expenses: 4300 },
];

const StatCard = ({ title, value, icon, trend, color }: any) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 transition-all hover:shadow-md">
    <div className="flex items-center justify-between mb-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white ${color}`}>
        <i className={`fa-solid ${icon} text-lg`}></i>
      </div>
      {trend && (
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${trend > 0 ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}>
          {trend > 0 ? '+' : ''}{trend}%
        </span>
      )}
    </div>
    <p className="text-slate-500 text-sm font-medium">{title}</p>
    <h3 className="text-2xl font-bold text-slate-800 mt-1">{value}</h3>
  </div>
);

const AdminDashboard = () => (
  <div className="space-y-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard title="Total Students" value="1,248" icon="fa-user-graduate" trend={12} color="bg-indigo-500" />
      <StatCard title="Total Teachers" value="84" icon="fa-chalkboard-teacher" trend={2} color="bg-emerald-500" />
      <StatCard title="Total Revenue" value="$42,500" icon="fa-dollar-sign" trend={8} color="bg-amber-500" />
      <StatCard title="Active Users" value="942" icon="fa-users" trend={-3} color="bg-rose-500" />
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          <h3 className="font-bold text-lg text-slate-800">Financial Overview</h3>
          <select className="bg-slate-50 border-none text-sm font-medium p-2 rounded-lg outline-none">
            <option>Last 7 Days</option>
            <option>Last 30 Days</option>
          </select>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
              />
              <Area type="monotone" dataKey="income" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
        <h3 className="font-bold text-lg text-slate-800 mb-6">Upcoming Events</h3>
        <div className="space-y-4 overflow-y-auto max-h-80">
          {[
            { title: 'Parent-Teacher Meeting', date: 'Tomorrow, 10:00 AM', type: 'meeting' },
            { title: 'Annual Sports Day', date: 'May 20, 2024', type: 'event' },
            { title: 'Summer Vacations Start', date: 'June 01, 2024', type: 'holiday' },
            { title: 'Grade 10 Final Exams', date: 'May 25, 2024', type: 'exam' },
          ].map((item, idx) => (
            <div key={idx} className="flex gap-4 p-4 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
              <div className="w-10 h-10 shrink-0 bg-white rounded-lg shadow-sm flex items-center justify-center">
                <i className={`fa-solid ${item.type === 'meeting' ? 'fa-people-group text-blue-500' : item.type === 'exam' ? 'fa-file-pen text-amber-500' : 'fa-calendar-star text-purple-500'}`}></i>
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">{item.title}</p>
                <p className="text-xs text-slate-500">{item.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const TeacherDashboard = () => (
  <div className="space-y-8">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <StatCard title="Assigned Classes" value="4" icon="fa-users" color="bg-emerald-500" />
      <StatCard title="My Students" value="124" icon="fa-user-graduate" color="bg-blue-500" />
      <StatCard title="Average Attendance" value="94%" icon="fa-check-circle" color="bg-purple-500" />
    </div>
    
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
      <h3 className="font-bold text-lg text-slate-800 mb-6">Class Performance Overview</h3>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={[
            { class: '10-A', avg: 82 },
            { class: '10-B', avg: 75 },
            { class: '11-C', avg: 88 },
            { class: '12-A', avg: 91 },
          ]}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="class" axisLine={false} tickLine={false} />
            <YAxis axisLine={false} tickLine={false} domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="avg" fill="#10b981" radius={[8, 8, 0, 0]} barSize={40} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  </div>
);

const StudentDashboard = () => (
  <div className="space-y-8">
    <div className="bg-indigo-600 rounded-2xl p-8 text-white relative overflow-hidden">
      <div className="relative z-10">
        <h2 className="text-3xl font-bold mb-2">Welcome back, Alice!</h2>
        <p className="opacity-80">Your final exams are starting in 12 days. Stay focused!</p>
        <button className="mt-6 bg-white text-indigo-600 px-6 py-2 rounded-xl font-bold hover:bg-slate-100 transition-colors">
          View Schedule
        </button>
      </div>
      <i className="fa-solid fa-graduation-cap absolute -right-4 -bottom-4 text-9xl opacity-10 rotate-12"></i>
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="font-bold text-lg text-slate-800 mb-6">My Subjects</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { name: 'Mathematics', teacher: 'John Doe', progress: 75, color: 'indigo' },
            { name: 'Physics', teacher: 'Jane Smith', progress: 60, color: 'blue' },
            { name: 'History', teacher: 'Michael Ross', progress: 90, color: 'emerald' },
            { name: 'English', teacher: 'Sarah Parker', progress: 85, color: 'violet' },
          ].map((subject, idx) => (
            <div key={idx} className="p-4 border border-slate-100 rounded-xl hover:bg-slate-50 transition-colors">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="font-bold text-slate-800">{subject.name}</h4>
                  <p className="text-xs text-slate-500">Teacher: {subject.teacher}</p>
                </div>
                <div className={`w-8 h-8 rounded-lg bg-${subject.color}-100 flex items-center justify-center`}>
                  <i className={`fa-solid fa-book text-${subject.color}-600`}></i>
                </div>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div 
                  className={`bg-${subject.color}-500 h-full rounded-full transition-all duration-1000`} 
                  style={{ width: `${subject.progress}%` }}
                ></div>
              </div>
              <p className="text-right text-[10px] font-bold text-slate-500 mt-1">{subject.progress}% Completed</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="font-bold text-lg text-slate-800 mb-6">Attendance Summary</h3>
        <div className="flex items-center justify-center h-64">
           {/* Simple Circle Progress visualization could go here */}
           <div className="relative w-48 h-48 rounded-full border-[12px] border-slate-100 flex items-center justify-center">
             <div className="absolute inset-0 rounded-full border-[12px] border-indigo-500 border-t-transparent -rotate-45"></div>
             <div className="text-center">
               <span className="text-4xl font-bold text-indigo-600">92%</span>
               <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">Attendance</p>
             </div>
           </div>
        </div>
      </div>
    </div>
  </div>
);

const ParentDashboard = () => (
  <div className="space-y-8">
     <div className="flex items-center justify-between">
       <h2 className="text-2xl font-bold text-slate-800">My Children</h2>
       <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2">
         <i className="fa-solid fa-plus"></i> Add Child
       </button>
     </div>
     
     <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
       {MOCK_STUDENTS.slice(0, 2).map((child) => (
         <div key={child.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
           <div className="p-8 flex items-center gap-6 border-b border-slate-50">
             <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(child.name)}&size=80`} className="w-20 h-20 rounded-2xl shadow-lg" alt="child" />
             <div>
               <h3 className="text-xl font-bold text-slate-800">{child.name}</h3>
               <p className="text-slate-500">{child.class} - Section {child.section}</p>
               <span className="inline-block mt-2 px-3 py-1 bg-emerald-100 text-emerald-600 text-xs font-bold rounded-full">Roll No: {child.rollNo}</span>
             </div>
           </div>
           <div className="p-8 grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-indigo-600">{child.attendance}%</p>
                <p className="text-xs text-slate-400 font-bold">Attendance</p>
              </div>
              <div className="text-center border-x border-slate-100">
                <p className="text-2xl font-bold text-emerald-600">A-</p>
                <p className="text-xs text-slate-400 font-bold">Avg Grade</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-amber-600">0</p>
                <p className="text-xs text-slate-400 font-bold">Pending Tasks</p>
              </div>
           </div>
           <div className="p-4 bg-slate-50 flex justify-center">
             <button className="text-indigo-600 font-bold text-sm hover:underline">View Detailed Report</button>
           </div>
         </div>
       ))}
     </div>
  </div>
);

const Dashboard: React.FC<{ role: UserRole }> = ({ role }) => {
  switch (role) {
    case UserRole.ADMIN: return <AdminDashboard />;
    case UserRole.TEACHER: return <TeacherDashboard />;
    case UserRole.STUDENT: return <StudentDashboard />;
    case UserRole.PARENT: return <ParentDashboard />;
    case UserRole.OWNER: return <AdminDashboard />;
    default: return <div className="p-8 text-center text-slate-500">Access Denied</div>;
  }
};

export default Dashboard;
