
import React, { useState } from 'react';
import { UserRole } from '../types';

interface LoginProps {
  onLogin: (user: any) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [tenantCode, setTenantCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState(1); // 1: Tenant Code, 2: Credentials

  const handleTenantSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tenantCode.length >= 3) setStep(2);
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple mock routing based on email prefix for demo
    let role = UserRole.ADMIN;
    let name = 'Super Admin';

    if (email.startsWith('teacher')) { role = UserRole.TEACHER; name = 'John Teacher'; }
    else if (email.startsWith('student')) { role = UserRole.STUDENT; name = 'Alice Student'; }
    else if (email.startsWith('parent')) { role = UserRole.PARENT; name = 'Robert Parent'; }
    else if (email.startsWith('owner')) { role = UserRole.OWNER; name = 'John Owner'; }

    onLogin({
      id: Math.random().toString(),
      name,
      email,
      role,
      schoolId: 'S001',
      schoolName: 'Global International School'
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Ornaments */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-violet-600/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl"></div>

      <div className="w-full max-w-md bg-white rounded-[2rem] shadow-2xl relative z-10 p-10">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-200">
            <i className="fa-solid fa-graduation-cap text-white text-3xl"></i>
          </div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight">EduNexus</h1>
          <p className="text-slate-500 font-medium">The Next Gen School OS</p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleTenantSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 block">School/Tenant Code</label>
              <div className="relative">
                <input 
                  type="text" 
                  required
                  value={tenantCode}
                  onChange={(e) => setTenantCode(e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all pl-12" 
                  placeholder="Enter your school code (e.g. GIS001)" 
                />
                <i className="fa-solid fa-building absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"></i>
              </div>
            </div>
            <button className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
              Next Step
              <i className="fa-solid fa-arrow-right"></i>
            </button>
            <p className="text-center text-xs text-slate-400">Don't have a school code? <a href="#" className="text-indigo-600 font-bold">Contact Support</a></p>
          </form>
        ) : (
          <form onSubmit={handleFinalSubmit} className="space-y-6">
            <button 
              type="button" 
              onClick={() => setStep(1)} 
              className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-indigo-600 mb-2"
            >
              <i className="fa-solid fa-arrow-left"></i>
              Change School ({tenantCode})
            </button>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 block">Email Address</label>
              <div className="relative">
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all pl-12" 
                  placeholder="Enter email..." 
                />
                <i className="fa-solid fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"></i>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-sm font-bold text-slate-700 block">Password</label>
                <a href="#" className="text-xs font-bold text-indigo-600 hover:underline">Forgot?</a>
              </div>
              <div className="relative">
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all pl-12" 
                  placeholder="••••••••" 
                />
                <i className="fa-solid fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"></i>
              </div>
            </div>
            <button className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all">
              Sign In to Dashboard
            </button>
            
            <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-[10px] text-slate-500">
               <p className="font-bold text-slate-400 uppercase">Demo Shortcuts:</p>
               <ul className="grid grid-cols-2 gap-1">
                 <li><code className="text-indigo-600 font-bold">admin@edu.com</code></li>
                 <li><code className="text-emerald-600 font-bold">teacher@edu.com</code></li>
                 <li><code className="text-violet-600 font-bold">student@edu.com</code></li>
                 <li><code className="text-amber-600 font-bold">parent@edu.com</code></li>
               </ul>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;
