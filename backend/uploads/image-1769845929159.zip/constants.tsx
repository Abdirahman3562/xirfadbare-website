
import { UserRole, Student, Teacher, Invoice } from './types';

export const MOCK_TENANTS = [
  { id: '1', name: 'Global International School', code: 'GIS001', logo: 'https://picsum.photos/id/1/100/100' },
  { id: '2', name: 'Valley View Academy', code: 'VVA002', logo: 'https://picsum.photos/id/2/100/100' },
];

export const MOCK_STUDENTS: Student[] = [
  { id: 'S1', rollNo: '101', name: 'Alice Johnson', class: 'Grade 10', section: 'A', parentName: 'Robert Johnson', status: 'active', attendance: 95 },
  { id: 'S2', rollNo: '102', name: 'Bob Smith', class: 'Grade 10', section: 'B', parentName: 'Mary Smith', status: 'active', attendance: 88 },
  { id: 'S3', rollNo: '103', name: 'Charlie Brown', class: 'Grade 9', section: 'A', parentName: 'Sarah Brown', status: 'inactive', attendance: 45 },
  { id: 'S4', rollNo: '104', name: 'Diana Prince', class: 'Grade 11', section: 'C', parentName: 'Hippolyta', status: 'active', attendance: 99 },
];

export const MOCK_TEACHERS: Teacher[] = [
  { id: 'T1', name: 'John Doe', subject: 'Mathematics', classes: ['Grade 10', 'Grade 11'], status: 'active' },
  { id: 'T2', name: 'Jane Smith', subject: 'Physics', classes: ['Grade 12'], status: 'on-leave' },
  { id: 'T3', name: 'Michael Ross', subject: 'History', classes: ['Grade 8', 'Grade 9'], status: 'active' },
];

export const MOCK_INVOICES: Invoice[] = [
  { id: 'INV-001', studentName: 'Alice Johnson', amount: 1200, dueDate: '2024-05-15', status: 'paid' },
  { id: 'INV-002', studentName: 'Bob Smith', amount: 1200, dueDate: '2024-05-15', status: 'unpaid' },
  { id: 'INV-003', studentName: 'Charlie Brown', amount: 950, dueDate: '2024-05-10', status: 'overdue' },
];

export const ROLE_COLORS = {
  [UserRole.OWNER]: 'bg-slate-600',
  [UserRole.ADMIN]: 'bg-indigo-600',
  [UserRole.TEACHER]: 'bg-emerald-600',
  [UserRole.STUDENT]: 'bg-violet-600',
  [UserRole.PARENT]: 'bg-amber-600',
};

export const ROLE_THEMES = {
  [UserRole.OWNER]: 'indigo',
  [UserRole.ADMIN]: 'indigo',
  [UserRole.TEACHER]: 'emerald',
  [UserRole.STUDENT]: 'violet',
  [UserRole.PARENT]: 'amber',
};
