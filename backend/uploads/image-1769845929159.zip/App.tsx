
import React, { useState, useEffect } from 'react';
import { User, UserRole } from './types';
import Login from './pages/Login';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import StudentsPage from './pages/Students';
import DataTable from './components/DataTable';
import { MOCK_TEACHERS, MOCK_INVOICES } from './constants';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Initial load simulation
    setTimeout(() => setIsLoaded(true), 500);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (!isLoaded) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-900">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white font-bold tracking-widest uppercase text-sm animate-pulse">Initializing Nexus...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard role={user.role} />;
      case 'students':
        return <StudentsPage />;
      case 'teachers':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Faculty Management</h2>
            <DataTable 
              title="Teacher List"
              columns={[
                { header: 'ID', accessor: 'id' as any },
                { header: 'Name', accessor: 'name' as any },
                { header: 'Subject', accessor: 'subject' as any },
                { header: 'Classes', accessor: (t: any) => t.classes.join(', ') },
                { header: 'Status', accessor: (t: any) => (
                   <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${t.status === 'active' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                     {t.status}
                   </span>
                )}
              ]} 
              data={MOCK_TEACHERS} 
            />
          </div>
        );
      case 'finance':
      case 'fees':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Financial Records</h2>
            <DataTable 
              title="Recent Invoices"
              columns={[
                { header: 'Inv #', accessor: 'id' as any },
                { header: 'Student', accessor: 'studentName' as any },
                { header: 'Amount', accessor: (i: any) => `$${i.amount}` },
                { header: 'Due Date', accessor: 'dueDate' as any },
                { header: 'Status', accessor: (i: any) => (
                  <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                    i.status === 'paid' ? 'bg-emerald-100 text-emerald-600' : 
                    i.status === 'overdue' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                  }`}>
                    {i.status}
                  </span>
                )}
              ]} 
              data={MOCK_INVOICES} 
            />
          </div>
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
             <i className="fa-solid fa-screwdriver-wrench text-6xl mb-6 opacity-20"></i>
             <h3 className="text-2xl font-bold">Work in Progress</h3>
             <p>This module ({activeTab}) is currently under active development.</p>
          </div>
        );
    }
  };

  return (
    <Layout 
      user={user} 
      onLogout={handleLogout} 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
