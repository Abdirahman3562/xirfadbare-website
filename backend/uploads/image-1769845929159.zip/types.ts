
export enum UserRole {
  OWNER = 'OWNER',
  ADMIN = 'ADMIN',
  TEACHER = 'TEACHER',
  STUDENT = 'STUDENT',
  PARENT = 'PARENT'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  schoolId: string;
  schoolName: string;
}

export interface Tenant {
  id: string;
  name: string;
  code: string;
  logo: string;
}

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  class: string;
  section: string;
  parentName: string;
  status: 'active' | 'inactive';
  attendance: number;
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  classes: string[];
  status: 'active' | 'on-leave';
}

export interface Invoice {
  id: string;
  studentName: string;
  amount: number;
  dueDate: string;
  status: 'paid' | 'unpaid' | 'overdue';
}
