
import React, { useState } from 'react';
import { UserRole } from '../types';
import { ROLE_COLORS } from '../constants';

interface LayoutProps {
  user: any;
  onLogout: () => void;
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ user, onLogout, children, activeTab, setActiveTab }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const menuItems = {
    [UserRole.ADMIN]: [
      { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-pie' },
      { id: 'students', label: 'Students', icon: 'fa-user-graduate' },
      { id: 'teachers', label: 'Teachers', icon: 'fa-chalkboard-teacher' },
      { id: 'classes', label: 'Classes & Subjects', icon: 'fa-school' },
      { id: 'attendance', label: 'Attendance', icon: 'fa-calendar-check' },
      { id: 'finance', label: 'Finance', icon: 'fa-file-invoice-dollar' },
      { id: 'exams', label: 'Exams & Grades', icon: 'fa-file-signature' },
      { id: 'settings', label: 'System Settings', icon: 'fa-cog' },
    ],
    [UserRole.TEACHER]: [
      { id: 'dashboard', label: 'Overview', icon: 'fa-home' },
      { id: 'my-classes', label: 'My Classes', icon: 'fa-users' },
      { id: 'attendance', label: 'Take Attendance', icon: 'fa-check-double' },
      { id: 'marks', label: 'Manage Marks', icon: 'fa-star' },
      { id: 'schedule', label: 'Schedule', icon: 'fa-clock' },
    ],
    [UserRole.STUDENT]: [
      { id: 'dashboard', label: 'My Study', icon: 'fa-book-open' },
      { id: 'exams', label: 'Exams', icon: 'fa-pen-clip' },
      { id: 'fees', label: 'Fees & Invoices', icon: 'fa-wallet' },
      { id: 'attendance', label: 'My Attendance', icon: 'fa-user-check' },
    ],
    [UserRole.PARENT]: [
      { id: 'dashboard', label: 'Children Stats', icon: 'fa-child' },
      { id: 'fees', label: 'Fee Payments', icon: 'fa-credit-card' },
      { id: 'performance', label: 'Performance', icon: 'fa-chart-line' },
    ],
    [UserRole.OWNER]: [
       { id: 'dashboard', label: 'Global Stats', icon: 'fa-globe' },
       { id: 'tenants', label: 'Manage Tenants', icon: 'fa-building' },
    ]
  };

  const currentMenu = menuItems[user.role as UserRole] || [];

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Sidebar */}
      <aside 
        className={`${isSidebarOpen ? 'w-64' : 'w-20'} transition-all duration-300 h-full bg-slate-900 text-white flex flex-col shadow-xl z-20`}
      >
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className={`w-8 h-8 rounded-lg ${ROLE_COLORS[user.role as UserRole]} flex items-center justify-center`}>
            <i className="fa-solid fa-graduation-cap text-white"></i>
          </div>
          {isSidebarOpen && <span className="font-bold text-lg tracking-tight">EduNexus</span>}
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto scrollbar-hide">
          {currentMenu.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? `${ROLE_COLORS[user.role as UserRole]} text-white shadow-lg` 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <i className={`fa-solid ${item.icon} w-5 text-center`}></i>
              {isSidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-4 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
          >
            <i className="fa-solid fa-right-from-bracket w-5 text-center"></i>
            {isSidebarOpen && <span className="font-medium">Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-full">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden"
            >
              <i className="fa-solid fa-bars"></i>
            </button>
            <h2 className="text-xl font-bold text-slate-800 capitalize">{activeTab.replace('-', ' ')}</h2>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative group hidden sm:block">
              <input 
                type="text" 
                placeholder="Search anything..." 
                className="pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:border-indigo-500 focus:bg-white rounded-full text-sm w-64 transition-all outline-none"
              />
              <i className="fa-solid fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
            </div>
            
            <div className="flex items-center gap-3 border-l border-slate-200 pl-6">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-800">{user.name}</p>
                <p className="text-xs text-slate-500">{user.role}</p>
              </div>
              <img 
                src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random`} 
                className="w-10 h-10 rounded-full border-2 border-white shadow-sm"
                alt="profile"
              />
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8 bg-slate-50/50">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
